﻿using Microsoft.EntityFrameworkCore;

namespace MinutoSeguros.LeitorFeed.Infra.Context
{
    public partial class MinutoSegurosContext : DbContext
	{
		public MinutoSegurosContext()
		{
        }

		public MinutoSegurosContext(DbContextOptions<MinutoSegurosContext> options)
			: base(options)
		{
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("");
            }
        }
	}
}
