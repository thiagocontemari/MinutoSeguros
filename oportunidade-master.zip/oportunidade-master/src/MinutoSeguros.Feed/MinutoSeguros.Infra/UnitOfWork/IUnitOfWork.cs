﻿using Microsoft.EntityFrameworkCore.Storage;

namespace MinutoSeguros.LeitorFeed.Infra.UnitOfWork
{
    public interface IUnitOfWork
    {
        void Commit();
        IDbContextTransaction BeginTransaction();
        void Rollback();
    }
}
