﻿using Microsoft.EntityFrameworkCore.Storage;
using MinutoSeguros.LeitorFeed.Infra.Context;

namespace MinutoSeguros.LeitorFeed.Infra.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly MinutoSegurosContext _context;

        public UnitOfWork(MinutoSegurosContext context)
        {
            _context = context;
        }

        public IDbContextTransaction BeginTransaction()
        {
            return _context.Database.BeginTransaction();
        }

        public void Commit()
        {
            _context.SaveChanges();
        }

        public void Rollback()
        {
            _context.Database.RollbackTransaction();
        }
    }
}
