﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Microsoft.EntityFrameworkCore;
using MinutoSeguros.LeitorFeed.Domain.Entities;
using MinutoSeguros.LeitorFeed.Domain.Interfaces.Repositories;
using MinutoSeguros.LeitorFeed.Infra.Context;

namespace MinutoSeguros.LeitorFeed.Infra.Repositories
{
    public class BaseRepository<T> : IBaseRepository<T> where T : BaseEntity
    {
        protected MinutoSegurosContext _context;
        protected DbSet<T> dbSet;

        public BaseRepository(MinutoSegurosContext context)
        {
            _context = context;
            dbSet = _context.Set<T>();
        }

        public virtual T Add(T obj)
        {
            return dbSet.Add(obj).Entity;
        }

        public virtual T GetById(int id)
        {
            return dbSet.Find(id);
        }

        public virtual IEnumerable<T> GetAll()
        {
            return dbSet;
        }

        public virtual T Update(T obj)
        {
            var entry = _context.Entry(obj);
            dbSet.Attach(obj);
            entry.State = EntityState.Modified;

            return obj;
        }

        public virtual void Delete(int id)
        {
            dbSet.Remove(dbSet.Find(id));
        }

        public IEnumerable<T> Search(Expression<Func<T, bool>> predicate)
        {
            return dbSet.Where(predicate);
        }

        public int Commit()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
