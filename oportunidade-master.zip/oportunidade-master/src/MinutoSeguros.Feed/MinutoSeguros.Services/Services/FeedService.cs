﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using MinutoSeguros.LeitorFeed.CrossCutting.Helpers;
using MinutoSeguros.LeitorFeed.Domain.Interfaces.Services;

namespace MinutoSeguros.LeitorFeed.Services.Services
{
    public class FeedService : IFeedService
    {
        private readonly IConfiguration _configuration;
        public FeedService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public List<string> RetornarOsDezUltimosConteudosDoFeed()
        {
            var itens = new List<string>();

            var itensDoFeed = FeedHelpers.Ler(_configuration.GetSection("UrlFeedMinutoSeguros").Value);

            foreach (var item in itensDoFeed.Items.OrderByDescending(m => m.PublishDate).Take(10))
            {
                itens.Add(item.Summary.Text);
            }

            return itens;
        }
    }
}
