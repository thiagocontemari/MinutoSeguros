﻿using System.Collections.Generic;
using System.Linq;
using MinutoSeguros.LeitorFeed.CrossCutting.Helpers;
using MinutoSeguros.LeitorFeed.Domain.Arguments.Palavra;
using MinutoSeguros.LeitorFeed.Domain.Interfaces.Services;

namespace MinutoSeguros.LeitorFeed.Services.Services
{
    public class PalavraService : IPalavraService
    {
        private readonly IFeedService _feedService;

        public PalavraService(IFeedService feedService)
        {
            _feedService = feedService;
        }

        public QuantidadePalavrasPorTopicoResponse ObterAQuantidadeDePalavrasPorTopico()
        {
            var retorno = new QuantidadePalavrasPorTopicoResponse();
            var conteudosDoFeed = _feedService.RetornarOsDezUltimosConteudosDoFeed();

            foreach (var conteudoDoFeed in conteudosDoFeed)
            {
                var conteudo = TextHelpers.RemoverTagsHtml(conteudoDoFeed);
                conteudo = TextHelpers.RemoverPreposicoesEArtigos(conteudo);
                conteudo = TextHelpers.RetornarApenasEspacosLetrasENumeros(conteudo);
                var palavras = TextHelpers.TransformarTextoEmLista(conteudo);

                int quantidadePalavras = palavras.Count();

                var frequenciaTopico = new QuantidadePalavrasPorTopicoItemResponse()
                {
                    Topico = $"{conteudoDoFeed.Substring(0, 49)} (...)",
                    QuantidadePalavras = quantidadePalavras
                };

                retorno.Frequencia.Add(frequenciaTopico);
            }

            return retorno;
        }

        public DezPrincipaisPalavrasAbordadasResponse RetornarAsDezPrincipaisPalavrasMaisAbordadas()
        {
            var retorno = new DezPrincipaisPalavrasAbordadasResponse();
            var palavras = new List<string>();
            var conteudosDoFeed = _feedService.RetornarOsDezUltimosConteudosDoFeed();

            foreach (var conteudoDoFeed in conteudosDoFeed)
            {
                palavras.AddRange(ObterPalavras(conteudoDoFeed));
            }

            var frequencia = ObterFrequenciaDasPalavras(palavras);

            retorno.Palavras = frequencia.Palavras.OrderByDescending(m => m.QuantidadeVezesPalavras).Take(10).ToList();

            return retorno;
        }

        public List<string> ObterPalavras(string conteudo)
        {
            var retorno = new List<string>();

            conteudo = TextHelpers.RemoverTagsHtml(conteudo);
            conteudo = TextHelpers.RetornarApenasEspacosLetrasENumeros(conteudo);
            var palavras = TextHelpers.TransformarTextoEmLista(conteudo);

            foreach (var palavra in palavras)
            {
                retorno.Add(palavra.ToLower().Trim());
            }

            return retorno;
        }

        public DezPrincipaisPalavrasAbordadasResponse ObterFrequenciaDasPalavras(List<string> palavras)
        {
            var retorno = new DezPrincipaisPalavrasAbordadasResponse();

            foreach (var palavraAgrupada in palavras.GroupBy(i => i))
            {
                var frequenciaPalavra = new DezPrincipaisPalavrasAbordadasItemResponse()
                {
                    Palavra = palavraAgrupada.Key,
                    QuantidadeVezesPalavras = palavraAgrupada.Count()
                };

                retorno.Palavras.Add(frequenciaPalavra);
            }

            return retorno;
        }
    }
}
