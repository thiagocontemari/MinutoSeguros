﻿using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using MinutoSeguros.LeitorFeed.Services.Services;
using Moq;
using NUnit.Framework;

namespace MinutoSeguros.LeitorFeed.Services.Tests
{
    [TestFixture]
    public class PalavraServiceTests
    {
        public static IConfiguration InitConfiguration()
        {
            return new ConfigurationBuilder().Build();
        }

        [Test]
        public void ObterPalavras_DeveraRetornarTodasAsPalavrasDescritasNoMock()
        {
            // arrange
            var mockTeste = "feed <a/> palavra  \n conteúdo <a> fato <b>atual</b>";
            var mockPalavraItens = new List<string>();
            mockPalavraItens.AddRange(new List<string>() { "feed", "palavra", "conteúdo", "fato", "atual" });

            var mock = new Mock<PalavraService>();
            mock.Setup(m => m.ObterPalavras(mockTeste)).Returns(mockPalavraItens);

            var feedService = new FeedService(InitConfiguration());
            var palavraService = new PalavraService(feedService);

            // act
            var resultadoEsperado = mock.Object.ObterPalavras(mockTeste);
            var resultado = palavraService.ObterPalavras(mockTeste);

            // assert
            Assert.AreEqual(resultado, resultadoEsperado);
        }
    }
}
