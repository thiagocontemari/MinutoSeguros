﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using MinutoSeguros.LeitorFeed.Domain.Interfaces.Services;
using MinutoSeguros.LeitorFeed.Services.Services;
using Moq;
using NUnit.Framework;

namespace MinutoSeguros.LeitorFeed.Services.Tests
{
    [TestFixture]
    public class FeedServiceTests
    {
        public static IConfiguration InitConfiguration()
        {
            return new ConfigurationBuilder().Build();
        }

        [Test]
        public void RetornarOsDezUltimosConteudosDoFeed_DeveraRetornarExatosDezItens()
        {
            // arrange
            var mockFeedItens = new List<string>();
            mockFeedItens.AddRange(new List<string>() { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });

            var mock = new Mock<IFeedService>();
            mock.Setup(m => m.RetornarOsDezUltimosConteudosDoFeed()).Returns(mockFeedItens);

            var feedService = new FeedService(InitConfiguration());

            // act
            var resultadoEsperado = mock.Object.RetornarOsDezUltimosConteudosDoFeed();
            var resultado = feedService.RetornarOsDezUltimosConteudosDoFeed();

            // assert
            Assert.AreEqual(resultado.Count(), resultadoEsperado.Count());
        }
    }
}
