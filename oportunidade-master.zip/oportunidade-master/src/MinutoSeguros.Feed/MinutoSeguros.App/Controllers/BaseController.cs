﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MinutoSeguros.LeitorFeed.Infra.UnitOfWork;

namespace MinutoSeguros.LeitorFeed.App.Controllers
{
    public class BaseController : ControllerBase
    {
        protected new IActionResult Response(object obj)
        {
            try
            {
                return Ok(obj);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
