﻿using Microsoft.AspNetCore.Mvc;
using MinutoSeguros.LeitorFeed.Domain.Arguments.Palavra;
using MinutoSeguros.LeitorFeed.Domain.Interfaces.Services;
using MinutoSeguros.LeitorFeed.Infra.UnitOfWork;

namespace MinutoSeguros.LeitorFeed.App.Controllers
{
    [Route("api/Palavras")]
    [ApiController]
    public class PalavraController : BaseController
    {
        private readonly IPalavraService _palavraService;

        public PalavraController(IPalavraService palavraService)
        {
            _palavraService = palavraService;
        }

        [HttpGet("DezPrincipaisMaisAbordadas")]
        [ProducesResponseType(typeof(DezPrincipaisPalavrasAbordadasResponse), 200)]
        public IActionResult RetornarAsDezPrincipaisPalavrasMaisAbordadas()
        {
            return Response(_palavraService.RetornarAsDezPrincipaisPalavrasMaisAbordadas());
        }

        [HttpGet("QuantidadePorTopico")]
        [ProducesResponseType(typeof(QuantidadePalavrasPorTopicoResponse), 200)]
        public IActionResult ObterAQuantidadeDePalavrasPorTopico()
        {
            return Response(_palavraService.ObterAQuantidadeDePalavrasPorTopico());
        }
    }
}
