﻿using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MinutoSeguros.LeitorFeed.App.Filters;
using MinutoSeguros.LeitorFeed.Domain.Entities;
using MinutoSeguros.LeitorFeed.Domain.Interfaces.Repositories;
using MinutoSeguros.LeitorFeed.Domain.Interfaces.Services;
using MinutoSeguros.LeitorFeed.Infra.Context;
using MinutoSeguros.LeitorFeed.Infra.Repositories;
using MinutoSeguros.LeitorFeed.Infra.UnitOfWork;
using MinutoSeguros.LeitorFeed.Services.Services;
using Swashbuckle.AspNetCore.Swagger;

namespace MinutoSeguros.LeitorFeed.App
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(options =>
            {
                options.Filters.Add(new ExceptionFilter());
            }).SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            //services.AddDbContext<MinutoSegurosContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MinutoSegurosContext")));

            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IBaseRepository<BaseEntity>, BaseRepository<BaseEntity>>();

            services.AddScoped<IFeedService, FeedService>();
            services.AddScoped<IPalavraService, PalavraService>();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "Leitor Feed", Version = "v1" });
                c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
            });
        }

        public void Configure(IApplicationBuilder app)
        {
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "Docs");
            });

            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
