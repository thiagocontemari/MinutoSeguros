﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace MinutoSeguros.LeitorFeed.Domain.Interfaces.Repositories
{
    public interface IBaseRepository<T> : IDisposable
    {
        T Add(T obj);
        T GetById(int id);
        IEnumerable<T> GetAll();
        T Update(T obj);
        void Delete(int id);
        IEnumerable<T> Search(Expression<Func<T, bool>> predicate);
        int Commit();
    }
}