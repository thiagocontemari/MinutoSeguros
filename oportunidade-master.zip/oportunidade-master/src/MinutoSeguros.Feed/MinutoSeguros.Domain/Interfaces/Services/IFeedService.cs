﻿using System.Collections.Generic;

namespace MinutoSeguros.LeitorFeed.Domain.Interfaces.Services
{
    public interface IFeedService
    {
        List<string> RetornarOsDezUltimosConteudosDoFeed();
    }
}
