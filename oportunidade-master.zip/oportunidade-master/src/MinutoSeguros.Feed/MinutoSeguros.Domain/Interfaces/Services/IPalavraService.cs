﻿using MinutoSeguros.LeitorFeed.Domain.Arguments.Palavra;

namespace MinutoSeguros.LeitorFeed.Domain.Interfaces.Services
{
    public interface IPalavraService
    {
        DezPrincipaisPalavrasAbordadasResponse RetornarAsDezPrincipaisPalavrasMaisAbordadas();
        QuantidadePalavrasPorTopicoResponse ObterAQuantidadeDePalavrasPorTopico();
    }
}
