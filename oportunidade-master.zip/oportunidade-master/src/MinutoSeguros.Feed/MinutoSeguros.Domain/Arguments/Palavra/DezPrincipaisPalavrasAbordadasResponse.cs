﻿using System.Collections.Generic;

namespace MinutoSeguros.LeitorFeed.Domain.Arguments.Palavra
{
    public class DezPrincipaisPalavrasAbordadasResponse
    {
        public DezPrincipaisPalavrasAbordadasResponse()
        {
            Palavras = new List<DezPrincipaisPalavrasAbordadasItemResponse>();
        }

        public List<DezPrincipaisPalavrasAbordadasItemResponse> Palavras { get; set; }
    }
}
