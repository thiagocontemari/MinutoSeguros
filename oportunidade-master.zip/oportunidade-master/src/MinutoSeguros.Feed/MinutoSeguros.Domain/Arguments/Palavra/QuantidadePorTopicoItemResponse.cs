﻿namespace MinutoSeguros.LeitorFeed.Domain.Arguments.Palavra
{
    public class QuantidadePalavrasPorTopicoItemResponse
    {
        public string Topico { get; set; }
        public int QuantidadePalavras { get; set; }
    }
}
