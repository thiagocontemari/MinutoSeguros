﻿namespace MinutoSeguros.LeitorFeed.Domain.Arguments.Palavra
{
    public class DezPrincipaisPalavrasAbordadasItemResponse
    {
        public string Palavra { get; set; }
        public int QuantidadeVezesPalavras { get; set; }
    }
}
