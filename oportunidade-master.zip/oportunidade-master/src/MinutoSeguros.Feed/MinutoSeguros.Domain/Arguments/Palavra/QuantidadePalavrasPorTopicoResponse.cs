﻿using System.Collections.Generic;

namespace MinutoSeguros.LeitorFeed.Domain.Arguments.Palavra
{
    public class QuantidadePalavrasPorTopicoResponse
    {
        public QuantidadePalavrasPorTopicoResponse()
        {
            Frequencia = new List<QuantidadePalavrasPorTopicoItemResponse>();
        }

        public List<QuantidadePalavrasPorTopicoItemResponse> Frequencia { get; set; }
    }
}
