﻿using System;
using System.Net;
using System.ServiceModel.Syndication;
using System.Xml;

namespace MinutoSeguros.LeitorFeed.CrossCutting.Helpers
{
    public static class FeedHelpers
    {
        public static SyndicationFeed Ler(string url)
        {
            try
            {
                if (HttpHelpers.ObterStatusCodeDaUrl(url) != HttpStatusCode.OK)
                    throw new Exception($"Erro ao acessar a url: {url}");

                using (var reader = XmlReader.Create(url))
                {
                    return SyndicationFeed.Load(reader);
                }
            }
            catch (Exception)
            {
                throw new Exception($"Erro ao obter o feed: {url}");
            }
        }
    }
}
