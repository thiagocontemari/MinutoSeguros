﻿using System;
using System.Net;

namespace MinutoSeguros.LeitorFeed.CrossCutting.Helpers
{
    public static class HttpHelpers
    {
        public static HttpStatusCode ObterStatusCodeDaUrl(string url)
        {
            var request = WebRequest.Create(url);
            var response = (HttpWebResponse)request.GetResponse();
            return response.StatusCode;
        }
    }
}
