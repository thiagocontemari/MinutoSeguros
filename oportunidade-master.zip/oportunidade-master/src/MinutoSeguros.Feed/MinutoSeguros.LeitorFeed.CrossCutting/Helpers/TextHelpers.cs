﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace MinutoSeguros.LeitorFeed.CrossCutting.Helpers
{
    public static class TextHelpers
    {
        public static string RetornarApenasEspacosLetrasENumeros(string palavra)
        {
            string pattern = @"[^0-9a-zA-Záéíóúàèìòùâêîôûãõç ]+";
            return new Regex(pattern).Replace(palavra, "");
        }

        public static string RemoverTagsHtml(string texto) => Regex.Replace(texto, "<.*?>", " ");

        public static List<string> TransformarTextoEmLista(string texto)
        {
            var itens = texto.Split(' ').ToList();
            return itens.Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
        }

        public static string RemoverPreposicoesEArtigos(string texto)
        {
            var preposicoesEArtigos = PreposicoesEArtigos();
            return string.Join(" ", texto.Split(' ').Except(preposicoesEArtigos));
        }

        public static string[] PreposicoesEArtigos()
        {
            var palavrasParaRemover = new string[] { "o", "os", "a", "as", "um", "uns", "uma", "umas", "ao", "aos", "à", "às", "do", "dos",
                                                     "da", "das", "dum", "duns", "duma", "dumas", "no", "nos", "na", "nas", "num", "nuns",
                                                     "numa", "numas", "pelo", "pelos", "pela", "pelas", "a", "de", "em", "por" };
            return palavrasParaRemover;
        }
    }
}
